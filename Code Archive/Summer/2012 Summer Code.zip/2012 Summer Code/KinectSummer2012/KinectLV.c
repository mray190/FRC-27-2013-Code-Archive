/* Call Library source file */

#include "extcode.h"

int32_t getDynamicControlData(uint8_t type, uint8_t data[], int32_t length, 
	int32_t wait_ticks);

int32_t getDynamicControlData(uint8_t type, uint8_t data[], int32_t length, 
	int32_t wait_ticks)
{

	/* Insert code here */

}

